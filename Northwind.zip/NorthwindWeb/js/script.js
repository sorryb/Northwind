﻿

$(document).ready(function () {
    //carousel interval
    $("#myCarousel").carousel({ interval: 5000 });
})

